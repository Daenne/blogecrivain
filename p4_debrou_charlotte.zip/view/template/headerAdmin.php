<section class="section has-background-link">
  <div class="container">
    <h1 class="title is-1 has-text-white">
      Interface utilisateur
    </h1>
    <nav class="level">
      <div class="level-right">
        <p class="level-item has-text-centere">
          <a class="has-text-white" href="index.php?action=admin">Gestion des articles</a>
        </p>
        <p class="level-item has-text-centered">
          <a class="has-text-white" href="index.php?action=adminComment">Gestion des commentaires</a>
        </p>
        <p class="level-item has-text-centered">
          <a class="has-text-white" href="index.php?action=endAdmin">Déconnexion</a>
        </p>
      </div>
    </nav> 
  </div>
</section>