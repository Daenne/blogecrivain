<footer class="footer has-background-link">
	<div class="container">	
		<div class="content has-text-centered">
    		<p class="has-text-white">
      		DB Charlotte - 2018
      		Site hébergé par 1&1 Internet SARL 7 place de la Gare BP 70109 57201 Sarreguemines Cedex
    		</p>
		</div>
	</div>
</footer>
</body>
</html>