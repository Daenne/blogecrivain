<?php include('./view/template/header.php'); ?>
<section class="section">
  <div class="container">
		<h2 class="title is-2">Le commentaire a bien été validé</h2>
		<a href="index.php?action=adminComment">Retour à la page de gestion des commentaires</a>
	</div>
</section>
<?php include('./view/template/footer.php'); ?>  
