<?php include('./view/template/header.php'); ?>
<section class="section">
  <div class="container">
		<h2 class="title is-2">Merci de votre contribution</h2>
		<p class="subtitle is-4">Le commentaire a bien été signalé</p>
		<a href="index.php?action=blog">Retour à la page d'accueil</a>
	</div>
</section>
<?php include('./view/template/footer.php'); ?>  
