<section class="hero is-link">
	<div class="hero-body">
		<div class="container">
		    <h1 class="title is-1">
		    Blog de Jean Forteroche
		    </h1>
		    <p class="subtitle is-3">
		    Bienvenue dans l'histoire ...
		    </p>
		</div>
	</div>
</section>
<?php include('./view/frontend/listArticlesView.php');?>