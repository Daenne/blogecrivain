<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <link rel="stylesheet" href="../Web/css/style.css" />
  </head>
  <body>
    <?php require('template/header.php'); ?>
<section>
    <h2>Titre de la partie accueil histoire de présenter</h2>
    <p>Ceci est un texte bref présent uniquement sur la page d'accueil</p>
</section>
<article>
   <?php require('listArticlesView.php');?>
</article>
<?php require('template/footer.php'); ?>
</body>
</html>
