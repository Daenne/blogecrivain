<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <link rel="stylesheet" href="../Web/css/style.css" />
		<title>A propos de Jean Forteroche</title>
	</head>
	<body>
		<?php include ('template/header.php'); ?>
		<section>
			<h2>Titre de la partie a propos histoire de présenter</h2>
			<p>Ceci est un texte bref présent uniquement sur la page à propos pour décrire l'auteur etc</p>
		</section>
		</article>
		<?php include ('template/footer.php'); ?>
	</body>
</html>