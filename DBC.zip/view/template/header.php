<header>
	<h1>Billet simple pour l'Alaska</h1>
	<p>Roman de jean Forteroche</p>
	<nav>
		<ul>
			<li><a href="index.php">Accueil</a></li>
			<li><a href="index.php?action=blog">Articles</a></li>
			<li><a href="./view/aproposView.php">A propos</a></li>
			<li><a href="./view/contactView.php">Contact</a></li>
		</ul>
	</nav>
	<p><a href="./view/loginView.php">Accéder à l'espace d'administration</a></p>
</header>