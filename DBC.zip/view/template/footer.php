<footer>
	<p>Mentions légales DB Charlotte</p>		
</footer>

