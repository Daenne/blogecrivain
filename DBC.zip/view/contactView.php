<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <link rel="stylesheet" href="../Web/css/style.css" />
		<title>Contacter Jean Forteroche</title>
	</head>
	<body>
		<?php include ('header.php'); ?>
		<section>
			<h2>Titre de la partie contact</h2>
			<p>On retrouvera ici un formulaire de contact</p>
		</section>
		<?php include ('footer.php'); ?>
	</body>
</html>